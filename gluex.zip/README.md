# HyperYield Optimizer

**A decentralized yield optimization protocol for HyperEVM leveraging GlueX APIs**

## 🎯 Overview

HyperYield Optimizer is an intelligent yield optimization protocol that automatically reallocates user funds across the highest-yielding opportunities on HyperEVM. Built for the Hyperliquid Community Hackathon, it combines ERC-7540 async vault standard with GlueX's powerful APIs to deliver optimal risk-adjusted returns.

### Key Features

- ✅ **ERC-7540 Compliant Vault** - Async deposit/redemption with institutional-grade security
- ✅ **Automated Yield Optimization** - Real-time monitoring of APY across whitelisted vaults
- ✅ **GlueX Integration** - Uses Yields API for discovery and Router API for execution
- ✅ **Risk Management** - Sharpe ratio optimization for best risk-adjusted returns
- ✅ **Transparent Operations** - All rebalancing actions are on-chain and auditable
- ✅ **Gas Efficient** - Batched operations minimize transaction costs

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     HyperYield Optimizer                     │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────────┐        ┌──────────────────┐           │
│  │  ERC-7540 Vault  │◄──────►│  Vault Manager   │           │
│  │  (On-Chain)      │        │  (On-Chain)      │           │
│  └──────────────────┘        └──────────────────┘           │
│           │                           │                       │
│           │                           │                       │
│           ▼                           ▼                       │
│  ┌──────────────────┐        ┌──────────────────┐           │
│  │  Optimizer Bot   │◄──────►│  GlueX Router    │           │
│  │  (Off-Chain)     │        │  API             │           │
│  └──────────────────┘        └──────────────────┘           │
│           │                           │                       │
│           ▼                           ▼                       │
│  ┌──────────────────┐        ┌──────────────────┐           │
│  │  GlueX Yields    │        │  Whitelisted     │           │
│  │  API             │        │  Vaults          │           │
│  └──────────────────┘        └──────────────────┘           │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

## 📦 Project Structure

```
hyperliquid-yield-optimizer/
├── contracts/              # Smart contracts (Solidity)
│   ├── HyperYieldVault.sol        # ERC-7540 vault implementation
│   ├── VaultManager.sol            # Whitelist & rebalancing logic
│   ├── interfaces/                 # Contract interfaces
│   └── test/                       # Contract tests
├── backend/                # Python optimizer service
│   ├── optimizer.py               # Main optimizer logic
│   ├── gluex_client.py           # GlueX API client
│   ├── yield_monitor.py          # Yield monitoring service
│   └── config.py                 # Configuration
├── frontend/               # React user interface
│   ├── src/
│   │   ├── components/           # React components
│   │   ├── hooks/                # Custom hooks
│   │   └── utils/                # Utilities
│   └── public/
├── scripts/                # Deployment & utility scripts
└── docs/                   # Documentation
```

## 🚀 Quick Start

### Prerequisites

- Node.js v18+
- Python 3.9+
- Foundry (for smart contracts)
- HyperEVM testnet access
- GlueX API credentials ([Get them here](https://portal.gluex.xyz))

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/hyperliquid-yield-optimizer
cd hyperliquid-yield-optimizer
```

2. **Install contract dependencies**
```bash
cd contracts
forge install
```

3. **Install backend dependencies**
```bash
cd ../backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

4. **Install frontend dependencies**
```bash
cd ../frontend
npm install
```

### Configuration

1. **Set up environment variables**
```bash
# Create .env file in project root
cp .env.example .env
```

2. **Configure your .env file**
```env
# Blockchain
HYPEREVM_RPC_URL=https://api.hyperliquid-testnet.xyz/evm
PRIVATE_KEY=your_private_key_here

# GlueX API
GLUEX_API_KEY=your_gluex_api_key
GLUEX_API_SECRET=your_gluex_secret

# Contract Addresses (after deployment)
VAULT_ADDRESS=
MANAGER_ADDRESS=

# Optimizer Settings
CHECK_INTERVAL=300  # 5 minutes
MIN_APY_DIFF=0.5    # 0.5% minimum difference to trigger rebalance
```

### Deployment

1. **Deploy smart contracts**
```bash
cd contracts
forge script script/Deploy.s.sol:DeployScript --rpc-url $HYPEREVM_RPC_URL --broadcast
```

2. **Update .env with deployed addresses**

3. **Start the optimizer backend**
```bash
cd backend
python optimizer.py
```

4. **Start the frontend**
```bash
cd frontend
npm run dev
```

5. **Access the app at** `http://localhost:3000`

## 🔧 How It Works

### 1. Deposit Flow

1. User deposits USDC into the HyperYield Vault
2. Vault issues async deposit request (ERC-7540)
3. Request becomes claimable after processing
4. User receives vault shares representing their position

### 2. Yield Monitoring

The optimizer backend continuously:
- Queries GlueX Yields API for APY data across whitelisted vaults
- Calculates risk-adjusted returns (Sharpe ratio)
- Identifies optimal reallocation opportunities
- Triggers rebalancing when threshold is exceeded

### 3. Rebalancing Flow

When a better yield opportunity is identified:
1. Optimizer calls VaultManager to initiate rebalance
2. VaultManager withdraws from current vault
3. Uses GlueX Router API to get optimal swap route
4. Executes swap and deposits into new vault
5. Emits rebalancing event for transparency

### 4. Withdrawal Flow

1. User requests redemption (async)
2. Shares are locked during request period
3. Vault processes withdrawal from underlying positions
4. User claims assets after cooling period

## 📊 Whitelisted GlueX Vaults

The protocol includes the following GlueX vaults:

| Vault Address | Description |
|---------------|-------------|
| `0xe25514992597786e07872e6c5517fe1906c0cadd` | GlueX Vault 1 |
| `0xcdc3975df9d1cf054f44ed238edfb708880292ea` | GlueX Vault 2 |
| `0x8f9291606862eef771a97e5b71e4b98fd1fa216a` | GlueX Vault 3 |
| `0x9f75eac57d1c6f7248bd2aede58c95689f3827f7` | GlueX Vault 4 |
| `0x63cf7ee583d9954febf649ad1c40c97a6493b1be` | GlueX Vault 5 |

## 🔐 Security Features

- **Async Vault Pattern**: ERC-7540 prevents flash loan attacks
- **Whitelist Control**: Only approved vaults can receive funds
- **Multi-sig Manager**: Critical operations require multiple signatures
- **Rate Limiting**: Prevents excessive rebalancing
- **Emergency Pause**: Circuit breaker for unforeseen issues
- **Audited Code**: Following OpenZeppelin best practices

## 🧪 Testing

### Smart Contracts
```bash
cd contracts
forge test -vv
```

### Backend
```bash
cd backend
pytest tests/
```

### Frontend
```bash
cd frontend
npm test
```

### Integration Tests
```bash
npm run test:integration
```

## 📈 Performance Metrics

Track optimizer performance through:
- **Total Value Locked (TVL)**
- **Current APY**
- **Historical Returns**
- **Sharpe Ratio**
- **Rebalancing History**
- **Gas Costs**

## 🎥 Demo

Watch our 3-minute demo video: [Link to demo video]

Demo walkthrough:
1. User deposits $1,000 USDC
2. Funds allocated to highest APY vault (12.5%)
3. Better opportunity detected (15.2% APY)
4. Automatic rebalancing executed
5. User withdraws with optimized returns

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## 📄 License

MIT License - see [LICENSE](LICENSE) for details

## 👥 Team

Built with ❤️ for the Hyperliquid Community Hackathon

## 🙏 Acknowledgments

- **GlueX Protocol** - For providing excellent APIs
- **Hyperliquid** - For the amazing infrastructure
- **Chorus One** - For mentorship and guidance

## 📞 Support

- Documentation: [Full docs](./docs)
- Issues: [GitHub Issues](https://github.com/yourusername/hyperliquid-yield-optimizer/issues)
- Discord: [Join our channel](https://discord.gg/hyperliquid)

---

**Built for Hyperliquid Community Hackathon 2025**

**Bounty: GlueX Yield Optimization Challenge ($3,000)**
